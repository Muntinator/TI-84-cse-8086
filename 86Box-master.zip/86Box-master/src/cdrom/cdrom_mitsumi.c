/*
 * 86Box    A hypervisor and IBM PC system emulator that specializes in
 *          running old operating systems and software designed for IBM
 *          PC systems and compatibles from 1981 through fairly recent
 *          system designs based on the PCI bus.
 *
 *          This file is part of the 86Box distribution.
 *
 *          Mitsumi CD-ROM emulation for the ISA bus.
 *
 * Authors: Miran Grca, <mgrca8@gmail.com>
 *          Jasmine Iwanek, <jriwanek@gmail.com>
 *
 *          Copyright 2022       Miran Grca.
 *          Copyright 2024-2025 Jasmine Iwanek.
 */

#include <inttypes.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <wchar.h>
#define HAVE_STDARG_H
#include <86box/86box.h>
#include <86box/device.h>
#include <86box/io.h>
#include <86box/pic.h>
#include <86box/dma.h>
#include <86box/cdrom.h>
#include <86box/cdrom_mitsumi.h>
#include <86box/plat.h>
#include <86box/ui.h>
#include <86box/timer.h>

#define RAW_SECTOR_SIZE    2352
#define COOKED_SECTOR_SIZE 2048
#define DMA_SERVICE_BUDGET 2048
#define MITSUMI_1X_SECTOR_TIME_US (1000000 / 75)
#define MITSUMI_2X_SECTOR_TIME_US (1000000 / 150)
#define MITSUMI_DMA_COUNT_BIAS    7

enum {
    STAT_CMD_CHECK = 0x01,
    STAT_PLAY_CDDA = 0x02,
    STAT_ERROR     = 0x04,
    STAT_DISK_CDDA = 0x08,
    STAT_SERVO     = 0x10,
    STAT_CHANGE    = 0x20,
    STAT_READY     = 0x40,
    STAT_OPEN      = 0x80
};
enum {
    CMD_GET_INFO   = 0x10,
    CMD_DISC_INFO  = 0x11,
    CMD_GET_Q      = 0x20,
    CMD_REQ_SENSE  = 0x30,
    CMD_GET_STAT   = 0x40,
    CMD_SET_MODE   = 0x50,
    CMD_SOFT_RESET = 0x60,
    CMD_STOPCDDA   = 0x70,
    CMD_GET_VOL    = 0x8e,
    CMD_CONFIG     = 0x90,
    CMD_SET_SMODE  = 0xa0, // sets mode of sector to read.
    CMD_SET_VOL    = 0xae,
    CMD_READ1X     = 0xc0,
    CMD_READ2X     = 0xc1,
    CMD_GET_VER    = 0xdc,
    CMD_STOP       = 0xf0,
    CMD_EJECT      = 0xf6,
    CMD_CLOSE      = 0xf8,
    CMD_LOCK       = 0xfe
};
enum {
    MODE_MUTE_DATA = 0x01,
    MODE_GET_TOC = 0x04,
    MODE_STOP    = 0x08,
    MODE_ECC     = 0x20,
    MODE_DATA    = 0x40
};
enum {
    DRV_MODE_STOP,
    DRV_MODE_READ,
    DRV_MODE_CDDA
};
enum {
    FLAG_NODATA = 2,
    FLAG_NOSTAT = 4,
    FLAG_UNK  = 8,
    FLAG_OPEN   = 16
};
enum {
    IRQ_DATAREADY = 1,
    IRQ_DATACOMP  = 2,
    IRQ_ERROR     = 4
};
enum {
    STATE_IDLE = 0,
    STATE_SEEK,
    STATE_STATUS,
    STATE_STATUS_WAIT,
    STATE_READ_SECTOR,
    STATE_ADVANCE_BUFFER,
    STATE_DATA_READY,
    STATE_WRITE_DMA
};
enum {
    STATUS_ERROR = -1,
    STATUS_NO_DATA = 0,
    STATUS_OK = 1,
    STATUS_AUDIO = 2
};

typedef struct mcd_t {
    uint16_t base;
    int      dma;
    int      irq;
    int      change;
    int      data;
    uint8_t  stat;
    uint8_t  buf[65536];
    int      buf_count;
    int      old_buf_count;
    int      buf_idx;
    int      real_count;
    uint8_t  cmdbuf[32];
    int      cmdbuf_count;
    int      cmdrd_count;
    int      cmdbuf_idx;
    uint8_t  mode;
    uint8_t  smode;
    uint8_t  cmd;
    uint8_t  conf;
    uint8_t  enable_irq;
    uint8_t  enable_dma;
    uint8_t  early_status;
    uint8_t  state;
    uint8_t  first;
    uint8_t  dma_timeout_ms;
    int8_t   status;
    uint16_t dmalen;
    uint32_t readmsf;
    uint32_t readcount;
    uint32_t audio_end_msf;
    uint32_t readbuflen;
    int      locked;
    int      drvmode;
    int      cur_toc_track;
    int      tray_open;
    uint32_t dma_retries;
    pc_timer_t read_timer;
    pc_timer_t dma_timeout_timer;
    uint8_t  last_flags;

    uint8_t  cur_control;
    uint8_t  cur_sense;

    uint8_t  temp_buf[0x10000];

    struct
    {
        uint8_t att0;
        uint8_t att1;
        uint8_t att2;
        uint8_t att3;
    } cdrom_vols;

    cdrom_t *cdrom_dev;
} mcd_t;

static void    mitsumi_read_callback(void *priv);

#define CD_DCB(x)         ((((x) &0xf0) >> 4) * 10 + ((x) &0x0f))

#ifdef ENABLE_MITSUMI_CDROM_LOG
int mitsumi_cdrom_do_log = ENABLE_MITSUMI_CDROM_LOG;

void
mitsumi_cdrom_log(const char *fmt, ...)
{
    va_list ap;

    if (mitsumi_cdrom_do_log) {
        va_start(ap, fmt);
        pclog_ex(fmt, ap);
        va_end(ap);
    }
}
#else
#    define mitsumi_cdrom_log(fmt, ...)
#endif

static int
mitsumi_cdrom_is_ready(const mcd_t *dev)
{
    return (dev->cdrom_dev != NULL) && (dev->cdrom_dev->ops != NULL) &&
           ((dev->cdrom_dev->cd_status & CD_STATUS_MASK) != CD_STATUS_EMPTY) &&
           ((dev->cdrom_dev->cd_status & CD_STATUS_MASK) != CD_STATUS_DVD_REJECTED);
}

static void
mitsumi_set_irq(const mcd_t *dev, const uint8_t mask)
{
    if ((dev->irq >= 0) && (dev->irq < 16) && (dev->enable_irq & mask)) {
        mitsumi_cdrom_log("Mitsumi: assert IRQ %d (event=%02x, mask=%02x)\n",
                          dev->irq, mask, dev->enable_irq);
        picint(1 << dev->irq);
    }
}

static int
mitsumi_msf_to_lba(const uint32_t msf, uint32_t *lba)
{
    const uint8_t minute_bcd = (msf >> 16) & 0xff;
    const uint8_t second_bcd = (msf >> 8) & 0xff;
    const uint8_t frame_bcd  = msf & 0xff;

    if (((minute_bcd & 0x0f) > 9) || ((minute_bcd >> 4) > 9) ||
        ((second_bcd & 0x0f) > 9) || ((second_bcd >> 4) > 9) ||
        ((frame_bcd & 0x0f) > 9) || ((frame_bcd >> 4) > 9))
        return 0;

    const uint8_t minute = CD_DCB(minute_bcd);
    const uint8_t second = CD_DCB(second_bcd);
    const uint8_t frame  = CD_DCB(frame_bcd);
    const uint32_t absolute_lba = MSFtoLBA(minute, second, frame);

    if ((second >= 60) || (frame >= 75) || (absolute_lba < 150))
        return 0;

    *lba = absolute_lba - 150;
    return 1;
}

static uint8_t
mitsumi_status(mcd_t *dev)
{
    uint8_t  status = 0;
    uint32_t lba    = 0;

    if (dev->tray_open)
        status |= STAT_OPEN;
    if (mitsumi_cdrom_is_ready(dev) && (dev->change != 2)) {
        status |= STAT_READY | STAT_SERVO;
        if (dev->cdrom_dev->cd_status & CD_STATUS_HAS_AUDIO) {
            if (!cdrom_has_data(dev->cdrom_dev))
                status |= STAT_DISK_CDDA;
            else if ((dev->cdrom_dev != NULL) && (dev->cdrom_dev->ops != NULL) &&
                     (dev->cdrom_dev->ops->get_track_type != NULL)) {
                if (mitsumi_msf_to_lba(dev->readmsf, &lba) &&
                    dev->cdrom_dev->ops->get_track_type(dev->cdrom_dev->local, lba) == CD_TRACK_AUDIO)
                    status |= STAT_DISK_CDDA;
            }
        }
    }
    if (dev->change > 0) {
        status |= STAT_CHANGE;
        dev->change--;
    }
    if (dev->cdrom_dev && (dev->cdrom_dev->cd_status == CD_STATUS_PLAYING))
        status |= STAT_PLAY_CDDA;

    return status;
}

static uint8_t
mitsumi_error_status(const mcd_t *dev, const int sense)
{
    uint8_t status = mitsumi_status((mcd_t*) dev) | STAT_ERROR;

    /* Invalid addresses/parameters are command errors.  Media and sector
       format failures are read errors and must not set COMMAND CHECK. */
    if (sense == 2)
        status |= STAT_CMD_CHECK;
    return status;
}

static void
mitsumi_abort_read(mcd_t *dev)
{
    if (timer_is_enabled(&dev->dma_timeout_timer))
        timer_disable(&dev->dma_timeout_timer);

    if (timer_is_enabled(&dev->read_timer))
        timer_disable(&dev->read_timer);

    dev->state      = STATE_IDLE;
    if ((dev->dma >= 0) && (dev->dma < 8))
        dma_set_drq(dev->dma, 0);
    dev->readcount  = 0;
    dev->buf_count  = 0;
    dev->real_count = 0;
    dev->buf_idx    = 0;
    dev->readbuflen = 0;
    dev->data       = 0;
    dev->drvmode    = DRV_MODE_STOP;
    ui_sb_update_icon(SB_CDROM | dev->cdrom_dev->id, 0);
}

static uint32_t
mitsumi_dma_length(const mcd_t *dev)
{
    /*
       Mask out the lower 3 bits, need for one of the DOS drivers to
       operate correctly.
     */
    return dev->dmalen & 0xfff8;
}

static void
mitsumi_cdrom_insert(void *priv)
{
    mcd_t *dev = (mcd_t *) priv;

    if ((dev == NULL) || (dev->cdrom_dev == NULL))
        return;

    mitsumi_abort_read(dev);
    cdrom_stop(dev->cdrom_dev);
    dev->change    = (mitsumi_cdrom_is_ready(dev)) ? 2 : 1;
    dev->tray_open = !mitsumi_cdrom_is_ready(dev);
    dev->stat      = mitsumi_status(dev);
    dev->change    = (mitsumi_cdrom_is_ready(dev)) ? 2 : 1;
    dev->cmdbuf_count = 0;
    picintc(1 << dev->irq);
}

static void
mitsumi_print_cmd(mcd_t* dev, uint8_t command) {
    char cmd_print[32] = { 0 };
    snprintf(cmd_print, sizeof(cmd_print) - 1, "0x%02x", command);

#define CASE(e) case e: \
                    mitsumi_cdrom_log("Mitsumi: command %s, params %d\n", #e, dev->cmdrd_count); \
                    break;
    
    switch (command) {
        default:
            mitsumi_cdrom_log("Mitsumi: command %s, params %d\n", cmd_print, dev->cmdrd_count);
            break;
        CASE(CMD_GET_INFO)
        CASE(CMD_DISC_INFO)
        CASE(CMD_GET_Q)
        CASE(CMD_REQ_SENSE)
        CASE(CMD_GET_STAT)
        CASE(CMD_SET_MODE)
        CASE(CMD_SOFT_RESET)
        CASE(CMD_STOPCDDA)
        CASE(CMD_GET_VOL)
        CASE(CMD_CONFIG)
        CASE(CMD_SET_SMODE)
        CASE(CMD_SET_VOL)
        CASE(CMD_READ1X)
        CASE(CMD_READ2X)
        CASE(CMD_GET_VER)
        CASE(CMD_STOP)
        CASE(CMD_EJECT)
        CASE(CMD_CLOSE)
        CASE(CMD_LOCK)
    }
}

static void
mitsumi_cdrom_reset(mcd_t *dev)
{
    picintc(1 << dev->irq);
    cdrom_stop(dev->cdrom_dev);
    dev->dma_timeout_ms  = 18;
    dev->cmdrd_count     = 0;
    dev->cmdbuf_count    = 0;
    dev->cmdbuf_idx      = 0;
    mitsumi_abort_read(dev);
    dev->cur_toc_track   = 0;
    dev->enable_dma      = 0;
    dev->enable_irq      = 0;
    dev->early_status    = 0;
    dev->mode            = 0;
    dev->cmd             = 0;
    dev->conf            = 0;
    dev->dmalen          = COOKED_SECTOR_SIZE + MITSUMI_DMA_COUNT_BIAS;
    dev->readmsf         = 0;
    dev->audio_end_msf   = 0;
    dev->dma_retries     = 0;
    dev->locked          = 0;
    dev->change          = 1;
    dev->data            = 0;
    dev->smode           = 1;
    dev->cur_control     = 0x0c;
    dev->cur_sense       = 0;
    dev->last_flags      = 0xff;
    dev->tray_open       = !mitsumi_cdrom_is_ready(dev);

    dev->cdrom_vols.att0 = 255;
    dev->cdrom_vols.att1 = 0;
    dev->cdrom_vols.att2 = 255;
    dev->cdrom_vols.att3 = 0;
    dev->stat            = mitsumi_status(dev);
}

uint8_t
mitsumi_disc_info(mcd_t *mcd, unsigned char *b)
{
    cdrom_t *dev               = mcd->cdrom_dev;
    uint8_t  track_type_buf[34];
    int      first_track;
    int      last_track;

    cdrom_read_toc(dev, mcd->temp_buf, CD_TOC_NORMAL, 0, 2 << 8, 65536);
    cdrom_get_track_buffer(mcd->cdrom_dev, track_type_buf);
    first_track = mcd->temp_buf[2];
    last_track  = mcd->temp_buf[3];

    // Yes, it returns first and last tracks in BCD format.
    b[0] = bin2bcd(first_track);
    b[1] = bin2bcd(last_track);


    b[5] = bin2bcd(track_type_buf[2]);
    b[6] = bin2bcd(track_type_buf[3]);
    b[7] = bin2bcd(track_type_buf[4]);
    uint32_t lo = cdrom_lba_to_msf_accurate(dev->cdrom_capacity + 1);
    b[2] = bin2bcd((lo >> 16) & 0xff);
    b[3] = bin2bcd((lo >> 8) & 0xff);
    b[4] = bin2bcd(lo & 0xff);
    return 1;
}

/* This is needed for early status. */
static int
mitsumi_cdrom_check_sector_error(mcd_t *dev)
{
    uint32_t lba;

    dev->data    = 0;

    if (!mitsumi_cdrom_is_ready(dev) || (dev->change > 0))
        return -1;

    if (!mitsumi_msf_to_lba(dev->readmsf, &lba))
        return -2;

    if (lba > dev->cdrom_dev->cdrom_capacity)
        return -2;

    return 1;
}

static int
mitsumi_cdrom_seek_sector(mcd_t *dev)
{
    uint8_t  status;
    uint32_t lba;
    uint32_t end_lba;

    dev->data    = 0;

    int ret = mitsumi_cdrom_check_sector_error(dev);

    if (ret != 1)
        return ret;

    if (dev->drvmode == DRV_MODE_CDDA) {
        /* C0 is both PLAY AUDIO and the single-speed data-read command.
           Data drivers conventionally pass FF:FF:FF as an open-ended range;
           only select audio mode when both addresses are valid and the start
           is actually on an audio track. */
        if (mitsumi_msf_to_lba(dev->readmsf, &lba) &&
            mitsumi_msf_to_lba(dev->audio_end_msf, &end_lba) && (end_lba > lba) &&
            (dev->cdrom_dev->ops->get_track_type(dev->cdrom_dev->local, lba) == CD_TRACK_AUDIO)) {
            status = cdrom_audio_play(dev->cdrom_dev, lba, end_lba - lba, 0);
            if (status == 1) {
                mitsumi_cdrom_log("Mitsumi read sector: Playing audio.\n");
                /* Audio playback has no data phase.  Keep DMA idle even when
                   the interface was configured for DMA before this command. */
                dev->readcount = 0;
                return 2;
            }
        }
        dev->drvmode = DRV_MODE_READ;
    }

    if (!dev->readcount) {
        mitsumi_cdrom_log("Mitsumi read complete at sector %u.\n", dev->cdrom_dev->seek_pos);
        cdrom_stop(dev->cdrom_dev);
        cdrom_seek(dev->cdrom_dev, lba, 0);
        dev->cur_toc_track = INT32_MIN;
        if (dev->cdrom_dev->seek_pos > dev->cdrom_dev->cdrom_capacity) {
            return -2;
        }
        return 0;
    }

    return 1;
}

static int
mitsumi_cdrom_read_sector(mcd_t *dev, int first)
{
    int      ret = 0;
    uint32_t lba = 0;
    uint32_t offset = 0;
    uint32_t available;

    dev->data    = 0;

    ret = mitsumi_cdrom_seek_sector(dev);

    if (ret != 1)
        return ret;

    if (!mitsumi_msf_to_lba(dev->readmsf, &lba))
        return -2;

    cdrom_stop(dev->cdrom_dev);
    cdrom_seek(dev->cdrom_dev, lba, 0);
    dev->cur_toc_track = INT32_MIN;
    if (dev->cdrom_dev->seek_pos > dev->cdrom_dev->cdrom_capacity) {
        return -2;
    }
    uint8_t data_flags = (dev->smode == 2) ? 0x50 : 0x10;
    ret = cdrom_readsector_raw(dev->cdrom_dev, dev->buf, dev->cdrom_dev->seek_pos, 0, (dev->smode == 2) ? 4 : 2, (dev->mode & 0x40) ? 0xF8 : data_flags, (int *) &dev->readbuflen, 0);

    mitsumi_cdrom_log("Mitsumi read sector @ %u, ret = %d, readlen = %u, blocklen = %u, mode = %02X, smode = %02X, dmalen = %04X\n",
                      dev->cdrom_dev->seek_pos, ret, dev->readbuflen, mitsumi_dma_length(dev), dev->mode, dev->smode, dev->dmalen);
    if (ret <= 0)
        return -3;
    const uint32_t next_msf = cdrom_lba_to_msf_accurate(dev->cdrom_dev->seek_pos + 1);
    dev->readmsf = (bin2bcd((next_msf >> 16) & 0xff) << 16) |
                   (bin2bcd((next_msf >> 8) & 0xff) << 8) |
                   bin2bcd(next_msf & 0xff);
    dev->buf_idx   = 0;

    if ((dev->readbuflen == 2048) && (dev->mode & 0x80))
        dev->readbuflen = 2050;

    available       = MIN(dev->readbuflen, RAW_SECTOR_SIZE);
    dev->buf_idx    = offset;
    available      -= offset;
    if (!(dev->mode & MODE_DATA)) {
        if (data_flags == 0x50)
            available = MIN(available, 2056);
        else {
            if (dev->mode & 0x80)
                available = MIN(available, COOKED_SECTOR_SIZE + 2);
            else
                available = MIN(available, COOKED_SECTOR_SIZE);
        }
    }
    dev->real_count = available;
    dev->buf_count  = MIN(mitsumi_dma_length(dev), available);
    if (dev->buf_count == 0)
        return -3;

    dev->data = 1;
    dev->readcount--;
    return 1;
}

static uint64_t
mitsumi_get_seek_period(mcd_t *dev)
{
    uint32_t lba = 0;

    mitsumi_msf_to_lba(dev->readmsf, &lba);

    dev->cdrom_dev->seek_diff = ABS(lba - dev->cdrom_dev->seek_pos);

    const double period = cdrom_seek_time(dev->cdrom_dev);

    return (uint64_t) (period * (double) TIMER_USEC);
}

static void
mitsumi_start_status_phase(mcd_t *dev, const int from_callback, const int status)
{
    dev->state = STATE_STATUS;
    if (from_callback)
        timer_advance_u64(&dev->read_timer, 10 * TIMER_USEC);
    else
        mitsumi_read_callback(dev);
    dev->status = (int8_t) status;
    if ((dev->status == STATUS_OK) && dev->early_status) {
        /* Report no data while we are delivering the status. */
        dev->old_buf_count = dev->buf_count;
        dev->buf_count = 0;
    }
    mitsumi_cdrom_log("[%s] Mitsumi: state advanced to STATE_STATUS\n",
                      (dev->status == STATUS_ERROR) ? "ERROR" :
                      ((dev->status == STATUS_AUDIO) ? "AUDIO" :
                      ((dev->status == STATUS_NO_DATA) ? "ND" : "OK")));
}

static void
mitsumi_start_seek_phase(mcd_t *dev, const int from_callback)
{
    dev->state = STATE_SEEK;
    if (from_callback)
        timer_advance_u64(&dev->read_timer, dev->first ? mitsumi_get_seek_period(dev) :
                                                         (10 * TIMER_USEC));
    else
        timer_set_delay_u64(&dev->read_timer, dev->first ? mitsumi_get_seek_period(dev) :
                                                         (10 * TIMER_USEC));
    mitsumi_cdrom_log("Mitsumi: [OK] state advanced to STATE_SEEK\n");
}

static void
mitsumi_start_read_phase(mcd_t *dev)
{
    ui_sb_update_icon(SB_CDROM | dev->cdrom_dev->id, 1);
    dev->state = STATE_READ_SECTOR;
    timer_advance_u64(&dev->read_timer, ((dev->cmd == CMD_READ2X) ?
                      MITSUMI_2X_SECTOR_TIME_US :
                      MITSUMI_1X_SECTOR_TIME_US) * TIMER_USEC);
    mitsumi_cdrom_log("Mitsumi: [OK] state advanced to STATE_READ_SECTOR\n");
}

static void
mitsumi_rearm_dma_timeout(mcd_t *dev)
{
    if (timer_is_enabled(&dev->dma_timeout_timer))
        timer_disable(&dev->dma_timeout_timer);

    timer_set_delay_u64(&dev->dma_timeout_timer,
                        (uint64_t) dev->dma_timeout_ms * 2000ULL * TIMER_USEC);
}

static void
mitsumi_start_data_ready_phase(mcd_t *dev, const int from_callback)
{
    if (dev->enable_dma) {
        mitsumi_rearm_dma_timeout(dev);
        dev->state = STATE_WRITE_DMA;
        timer_advance_u64(&dev->read_timer, 1ULL << 32);
        mitsumi_cdrom_log("Mitsumi: [OK] state advanced to STATE_WRITE_DMA\n");
    } else {
        dev->state = STATE_DATA_READY;
        if (from_callback)
            timer_advance_u64(&dev->read_timer, 10 * TIMER_USEC);
        else
            timer_set_delay_u64(&dev->read_timer, 10 * TIMER_USEC);
        mitsumi_cdrom_log("Mitsumi: [OK] state advanced to STATE_DATA_READY\n");
    }
}

static int
mitsumi_dma_transfer(mcd_t *dev)
{
    int      dma_result = 0;
    uint32_t service_budget;

    /* DMA channels 5-7 count words rather than bytes.  Service a bounded
       number of DMA units at a time, but only finish the request when the DMA
       controller reports terminal count. */
    if ((dev->dma < 0) || (dev->dma >= 8) || (dma[dev->dma].cc < 0))
        return 1;
    service_budget = MIN((uint32_t) dma[dev->dma].cc + 1, DMA_SERVICE_BUDGET);

    while (dev->buf_count > 0) {
        if (!cpu_thread_run || is_quit || hard_reset_pending) {
            mitsumi_abort_read(dev);
            return 0;
        }
        const int transfer_bytes = ((dev->dma >= 4) && (dev->buf_count > 1)) ? 2 : 1;
        uint16_t  value = dev->buf[dev->buf_idx];

        if (transfer_bytes == 2)
            value |= dev->buf[dev->buf_idx + 1] << 8;

        dma_result = dma_channel_write(dev->dma, value);
        if (dma_result == DMA_NODATA)
            return 1;
        dev->buf_idx += transfer_bytes;
        dev->buf_count -= transfer_bytes;

        if (dma_result & DMA_OVER) {
            mitsumi_cdrom_log("Mitsumi: DMA terminal count at buffer offset %d\n", dev->buf_idx);
            if (timer_is_enabled(&dev->dma_timeout_timer))
                timer_disable(&dev->dma_timeout_timer);
            dma_set_drq(dev->dma, 0);
            dev->buf_count  = 0;
            dev->buf_idx    = 0;
            dev->readbuflen = 0;
            dev->data       = 0;
            mitsumi_set_irq(dev, IRQ_DATACOMP);
            if (dev->readcount && dev->enable_dma &&
                (dev->drvmode == DRV_MODE_READ)) {
                const int buf_len = mitsumi_dma_length(dev);
                if (dev->real_count > buf_len) {
                    mitsumi_rearm_dma_timeout(dev);
                    dev->real_count -= buf_len;
                    memcpy(dev->buf, &(dev->buf[buf_len]), dev->real_count);
                    dev->buf_idx     = 0;
                    dev->buf_count   = MIN(dev->real_count, buf_len);
                    timer_advance_u64(&dev->read_timer, 1ULL << 32);
                } else
                    mitsumi_start_seek_phase(dev, 1);
            } else {
                mitsumi_cdrom_log("Mitsumi: [DMA] timer stopped\n");
                timer_disable(&dev->read_timer);
                dev->drvmode = DRV_MODE_STOP;
                dev->state = STATE_IDLE;
            }
            return 0;
        }
        if (--service_budget == 0)
            return 2;
    }

    /* Do not fetch another host-image sector in this callback.  A real
       single/double-speed drive makes sectors available at 75/150 Hz. */
    return 3;
}

static void
mitsumi_dma_timeout_callback(void *priv)
{
    mcd_t    *dev      = (mcd_t *) priv;

    dev->cur_sense    = 3;
    dev->stat         = mitsumi_error_status(dev, dev->cur_sense);
    mitsumi_abort_read(dev);
    mitsumi_set_irq(dev, IRQ_ERROR);
    dev->cmdbuf_idx   = 0;
    dev->cmdbuf_count = 1;
    dev->cmdbuf[0]    = dev->stat;
}

static void
mitsumi_read_callback(void *priv)
{
    mcd_t    *dev      = (mcd_t *) priv;
    int       read_res = 0;

    if (!cpu_thread_run || is_quit || hard_reset_pending) {
        mitsumi_abort_read(dev);
        return;
    }

    const int buf_len = mitsumi_dma_length(dev);

    switch (dev->state) {
        default:
            mitsumi_cdrom_log("Mitsumi: state UNKNOWN %02X\n", dev->state);
            break;
        case STATE_IDLE:
            mitsumi_cdrom_log("Mitsumi: state STATE_IDLE\n");
            break;
        case STATE_SEEK:
            mitsumi_cdrom_log("Mitsumi: state STATE_SEEK\n");
            if (!dev->readcount && dev->early_status) {
                /*
                  For DMA and early-status PIO reads,
                  readcount = 0 means read until TC.
                */
                dev->readcount = 0xffffffff;
                /* Set the end MSF to 99:59.74. */
                dev->audio_end_msf = 0x00995974;
            }

            read_res = mitsumi_cdrom_seek_sector(dev);

            switch (read_res) {
               default:
                    /* Error. */
                    dev->cur_sense = abs(read_res);
                    dev->cmdbuf[0] = mitsumi_error_status(dev, dev->cur_sense);
                    mitsumi_set_irq(dev, IRQ_ERROR);

                    mitsumi_start_status_phase(dev, 1, STATUS_ERROR);
                    break;
                case 0: case 2:
                    /* Seek or audio play, just return status if needed. */
                    dev->cmdbuf[0] = mitsumi_status(dev);

                    mitsumi_start_status_phase(dev, 1, read_res);
                    break;
                case 1:
                    /* Data read. */
                    dev->cmdbuf_count = 0;

                    mitsumi_start_read_phase(dev);
                    break;
            }
            break;
        case STATE_STATUS:
            mitsumi_cdrom_log("Mitsumi: state STATE_STATUS\n");
            dev->cmdbuf_count = 1;
            dev->cmdbuf_idx = 0;

            if (dev->status == STATUS_OK)
                dev->state = STATE_STATUS_WAIT;
            else
                dev->state = STATE_IDLE;
            break;
        case STATE_READ_SECTOR:
            mitsumi_cdrom_log("Mitsumi: state STATE_READ_SECTOR\n");
            read_res = mitsumi_cdrom_read_sector(dev, dev->first);

            ui_sb_update_icon(SB_CDROM | dev->cdrom_dev->id, 0);

            switch (read_res) {
                default:
                    /* Error. */
                    dev->cur_sense = abs(read_res);
                    dev->cmdbuf[0] = mitsumi_error_status(dev, dev->cur_sense);
                    mitsumi_set_irq(dev, IRQ_ERROR);

                    mitsumi_start_status_phase(dev, 1, STATUS_ERROR);
                    break;
                case 0: case 2:
                    /* Read nothing or audio play, just return status if needed. */
                    dev->cmdbuf[0] = mitsumi_status(dev);

                    mitsumi_start_status_phase(dev, 1, read_res);
                    break;
                case 1:
                    /* Read successful. */
                    if (dev->first && dev->early_status && !dev->enable_dma) {
                        /* In DMA mode, the status always follows immediately. */
                        dev->cmdbuf[0] = mitsumi_status(dev);
                        mitsumi_start_status_phase(dev, 1, STATUS_OK);
                    } else
                        mitsumi_start_data_ready_phase(dev, 1);
                    if (dev->first && dev->enable_dma) {
                        dev->dma_retries = 0;
                        dma_set_drq(dev->dma, 1);
                        dev->cmdbuf_count = 1;
                        dev->cmdbuf_idx = 0;
                    }
                    break;
            }

            if (dev->first)
                dev->first = 0;
            break;
        case STATE_DATA_READY:
            mitsumi_cdrom_log("Mitsumi: state STATE_DATA_READY\n");
            mitsumi_set_irq(dev, IRQ_DATAREADY);
            dev->state = STATE_IDLE;
            mitsumi_cdrom_log("Mitsumi: [DR OK] state advanced to STATE_IDLE\n");
            break;
        case STATE_ADVANCE_BUFFER:
            mitsumi_cdrom_log("Mitsumi: state ADVANCE_BUFFER\n");
            dev->real_count -= buf_len;
            memcpy(dev->buf, &(dev->buf[buf_len]), dev->real_count);
            dev->buf_idx     = 0;
            dev->buf_count   = MIN(dev->real_count, buf_len);
            mitsumi_cdrom_log("Mitsumi CD-ROM: [%s] Moved the next %i bytes "
                              "into the buffer.\n", dev->enable_dma ? "DMA" : "PIO",
                              dev->buf_count);
            break;
        case STATE_WRITE_DMA:
            mitsumi_cdrom_log("Mitsumi: state STATE_WRITE_DMA\n");
            read_res = mitsumi_dma_transfer(dev);
            if ((read_res > 1) && (timer_is_enabled(&dev->dma_timeout_timer)))
                timer_disable(&dev->dma_timeout_timer);
            switch (read_res) {
                default:
                    break;
                case 1:
                    /* The channel may still be masked or owned by another requester.
                       Keep DRQ asserted and retry without blocking the emulation thread. */
                    if ((dma[dev->dma].cc < 0) || (dma_m & (1 << dev->dma)) ||
                        ((dma[dev->dma].mode & 0x0c) != 0x04)) {
                        /* The DOS driver enables the interface before it finishes
                           programming and briefly unmasking the 8237 channel.  None of
                           those waiting states is a read error. */
                        mitsumi_cdrom_log("Mitsumi: DMA not writable (channel=%d, cc=%d, mode=%02x, size=%d, enabled=%02x, masked=%02x, writable=%d, result=%d)\n",
                                          dev->dma, dma[dev->dma].cc, dma[dev->dma].mode,
                                          dma[dev->dma].size, dma_e, dma_m,
                                          dma_channel_writable(dev->dma), read_res);
                        timer_advance_u64(&dev->read_timer, 100 * TIMER_USEC);
                        break;
                    }
                    if (!dev->dma_retries)
                        mitsumi_cdrom_log("Mitsumi: DMA stalled (channel=%d, cc=%d, mode=%02x, size=%d, enabled=%02x, masked=%02x, writable=%d, result=%d)\n",
                                          dev->dma, dma[dev->dma].cc, dma[dev->dma].mode,
                                          dma[dev->dma].size, dma_e, dma_m,
                                          dma_channel_writable(dev->dma), read_res);
                    if (++dev->dma_retries < 10000) {
                        /* MTMCDAE briefly unmasks the 8237 channel and then polls for
                           terminal count.  Retry on the next CPU cycle so the emulated
                           drive cannot miss that short DMA service window. */
                        timer_advance_u64(&dev->read_timer, 1ULL << 32);
                        return;
                    }
                    dev->cur_sense = 3;
                    dev->stat      = mitsumi_error_status(dev, dev->cur_sense);
                    mitsumi_abort_read(dev);
                    mitsumi_set_irq(dev, IRQ_ERROR);
                    break;
                case 2:
                    /* Yield between chunks so reset, pause and shutdown requests can be
                       handled even during a large or open-ended DMA transfer. */
                    dev->dma_retries = 0;
                    if (dev->buf_count == 0) {
                        if (dev->readcount > 0) {
                            /* Another sector to read or more data from the buffer. */
                            if (dev->real_count > buf_len) {
                                mitsumi_rearm_dma_timeout(dev);
                                dev->real_count -= buf_len;
                                memcpy(dev->buf, &(dev->buf[buf_len]), dev->real_count);
                                dev->buf_idx     = 0;
                                dev->buf_count   = MIN(dev->real_count, buf_len);
                                timer_advance_u64(&dev->read_timer, 10 * TIMER_USEC);
                            } else
                                mitsumi_start_seek_phase(dev, 1);
                        } else if (!dev->early_status) {
                            /* Exhausted everything and not early status. */
                            dev->cmdbuf[0] = mitsumi_status(dev);
                            mitsumi_start_status_phase(dev, 1, STATUS_NO_DATA);
                        } else
                            /* Exhausted everything and early status. */
                            dev->state = STATE_IDLE;
                    } else {
                        /* Buffer not (yet) exhausted. */
                        mitsumi_rearm_dma_timeout(dev);
                        timer_advance_u64(&dev->read_timer, 10 * TIMER_USEC);
                    }
                    break;
                case 3:
                    dev->dma_retries = 0;
                    if (dev->readcount > 0) {
                        if (dev->real_count > buf_len) {
                            mitsumi_rearm_dma_timeout(dev);
                            dev->real_count -= buf_len;
                            memcpy(dev->buf, &(dev->buf[buf_len]), dev->real_count);
                            dev->buf_idx     = 0;
                            dev->buf_count   = MIN(dev->real_count, buf_len);
                            timer_advance_u64(&dev->read_timer, 1ULL << 32);
                        } else
                            mitsumi_start_seek_phase(dev, 1);
                    } else if (!dev->early_status) {
                        dev->cmdbuf[0] = mitsumi_status(dev);
                        mitsumi_start_status_phase(dev, 1, STATUS_NO_DATA);
                    } else
                        dev->state = STATE_IDLE;
                    break;
            }
            break;
    }
}

static uint8_t
mitsumi_cdrom_get_flags(mcd_t* dev)
{
    uint8_t ret = 0;
    if (!dev->buf_count || !dev->data || dev->enable_dma)
        ret |= FLAG_NODATA;
    if (!dev->cmdbuf_count)
        ret |= FLAG_NOSTAT;

    if (dev->tray_open)
        ret |= FLAG_OPEN;

    return ret | FLAG_UNK | 1;
}

#include "cpu.h"

static uint8_t
mitsumi_cdrom_in(uint16_t port, void *priv)
{
    mcd_t  *dev = (mcd_t *) priv;
    uint8_t ret = 0xff;

    switch (port & 3) {
        case 0:
            if (dev->cmdbuf_count && !(mitsumi_cdrom_get_flags(dev) & FLAG_NOSTAT)) {
                dev->cmdbuf_count--;
                ret = dev->cmdbuf[dev->cmdbuf_idx++];
                if ((dev->cmdbuf_count == 0) &&
                    ((dev->cmd == CMD_READ1X) || (dev->cmd == CMD_READ2X)) &&
                    (dev->state == STATE_STATUS_WAIT) && !dev->enable_dma) {
                    dev->buf_count     = dev->old_buf_count;
                    dev->old_buf_count = 0;
                    mitsumi_start_data_ready_phase(dev, 0);
                }
                mitsumi_cdrom_log("Mitsumi: response cmd=%02x byte=%02x remaining=%d\n",
                                  dev->cmd, ret, dev->cmdbuf_count);
                return ret;
            }
            if (dev->buf_count && !(mitsumi_cdrom_get_flags(dev) & FLAG_NODATA)) {
                ret = dev->buf[dev->buf_idx];
                dev->buf_idx++;
                dev->buf_count--;
                if (!dev->buf_count) {
                    mitsumi_set_irq(dev, IRQ_DATACOMP);
                    const int buf_len = mitsumi_dma_length(dev);
                    mitsumi_cdrom_log("Mitsumi CD-ROM: Real count = %i, buffer length = %i\n",
                                      dev->real_count, buf_len);
                    if (dev->real_count > buf_len) {
                        /* Advance instantly - OS/2's REP INSB does *NOT* like waits. */
                        dev->real_count -= buf_len;
                        memcpy(dev->buf, &(dev->buf[buf_len]), dev->real_count);
                        dev->buf_idx     = 0;
                        dev->buf_count   = MIN(dev->real_count, buf_len);
                        mitsumi_set_irq(dev, IRQ_DATAREADY);
                        mitsumi_cdrom_log("Mitsum CD-ROM: [PIO] Moved the next %i bytes into the buffer.\n", dev->buf_count);
                    } else {
                        /*
                           Do PIO transfers on a timer, fixes the Windows 9x driver in
                           IRQ mode.
                         */
                        if (dev->readcount > 0)
                            mitsumi_start_seek_phase(dev, 0);
                        else {
                            if (!dev->early_status) {
                                dev->cmdbuf[0] = mitsumi_status(dev);
                                mitsumi_start_status_phase(dev, 0, STATUS_NO_DATA);
                            }
                            dev->cur_toc_track = INT32_MIN;
                            mitsumi_cdrom_log("Mitsumi PIO read complete at sector %u.\n", dev->cdrom_dev->seek_pos);
                        }
                    }
                }
                mitsumi_cdrom_log("Mitsumi: data cmd=%02x byte=%02x remaining=%d (ECX=%08X)\n",
                                  dev->cmd, ret, dev->buf_count, ECX);
                return ret;
            }
            mitsumi_cdrom_log("Mitsumi: byte=ff\n");
            return 0xff;
        case 1:
            picintc(1 << dev->irq);
            ret = mitsumi_cdrom_get_flags(dev);
            mitsumi_cdrom_log("Mitsumi: [%04X:%08X] flags=%02x (data=%d, bytes=%d, status=%d)\n",
                              CS, cpu_state.pc, ret, dev->data, dev->buf_count, dev->cmdbuf_count);
            if (ret != dev->last_flags)
                dev->last_flags = ret;
            return ret;
        case 2:
            return 0xFF;
        case 3:
            return 0xFF;
        default:
            break;
    }

    return ret;
}

void
mitsumi_read_multisess(mcd_t* mcd, uint8_t* b)
{
    cdrom_t      *dev            = mcd->cdrom_dev;
    const raw_track_info_t *trti = (raw_track_info_t *) mcd->temp_buf;
    int           num            = 0;
    int           first_sess     = 0;
    int           last_sess      = 0;

    dev->ops->get_raw_track_info(dev->local, &num, mcd->temp_buf);

    memset(b, 0x00, 4);
    if (num > 0) {
        int trk = -1;

        for (int i = 0; i < num; i++) {
            if (trti[i].point == 0xa2) {
                first_sess = trti[i].session;
                break;
            }
        }

        for (int i = (num - 1); i >= 0; i--) {
            if (trti[i].point == 0xa2) {
                last_sess = trti[i].session;
                break;
            }
        }

        for (int i = 0; i < num; i++) {
            if ((trti[i].point >= 1) && (trti[i].point <= 99) &&
                (trti[i].session == last_sess)) {
                trk = i;
                break;
            }
        }

        if ((first_sess > 0) && (last_sess > first_sess) && (trk != -1)) {
            b[0] = 0x01;
            b[1] = bin2bcd(trti[trk].pm);
            b[2] = bin2bcd(trti[trk].ps);
            b[3] = bin2bcd(trti[trk].pf);
        }
    }
    mitsumi_cdrom_log("Mitsumi multisession: %02X %02X %02X %02X\n", b[0], b[1], b[2], b[3]);
}

static void
mitsumi_cdrom_out(uint16_t port, uint8_t val, void *priv)
{
    mcd_t   *dev      = (mcd_t *) priv;

    mitsumi_cdrom_log("Mitsumi CD-ROM OUT=%03x, val=%02x\n", port, val);
    switch (port & 3) {
        case 0:
            if (dev->cmdrd_count) {
                dev->cmdrd_count--;
                switch (dev->cmd) {
                    case CMD_SET_SMODE:
                        dev->smode        = val;
                        break;
                    case CMD_SET_MODE:
                        dev->mode         = val;
                        dev->cmdbuf[1]    = 0;
                        dev->cmdbuf_count = 2;
                        break;
                    case CMD_LOCK:
                        dev->locked       = val & 1;
                        dev->cmdbuf[1]    = 0;
                        dev->cmdbuf[2]    = 0;
                        dev->cmdbuf_count = 3;
                        break;
                    case CMD_SET_VOL:
                        switch (dev->cmdrd_count) {
                            default:
                                break;
                            case 3:
                                dev->cdrom_vols.att0 = val;
                                break;
                            case 2:
                                dev->cdrom_vols.att1 = val;
                                break;
                            case 1:
                                dev->cdrom_vols.att2 = val;
                                break;
                            case 0:
                                dev->cdrom_vols.att3 = val;
                                break;
                        }
                        break;
                    case CMD_CONFIG:
                        switch (dev->cmdrd_count) {
                            case 0:
                                switch (dev->conf) {
                                    case 0x01:
                                        dev->dmalen |= val;
                                        mitsumi_cdrom_log("Mitsumi: DMA length register=%04x, decoded=%u\n",
                                                          dev->dmalen, mitsumi_dma_length(dev));
                                        break;
                                    case 0x02:
                                        dev->enable_dma = val;
                                        mitsumi_cdrom_log("Mitsumi: DMA enable=%02x, channel=%d\n",
                                                          dev->enable_dma, dev->dma);
                                        if (!dev->enable_dma) {
                                            mitsumi_abort_read(dev);
                                        } else if (dev->data && dev->buf_count) {
                                            /* MTMCDAE may enable DMA after the
                                               read command has made its first
                                               sector available. */
                                            dev->dma_retries = 0;
                                            dma_set_drq(dev->dma, 1);
                                        }
                                        break;
                                    case 0x08:
                                        dev->dma_timeout_ms = val;
                                        mitsumi_cdrom_log("Mitsumi: DMA timeout=%i ms\n",
                                                          dev->dma_timeout_ms);
                                        break;
                                    case 0x10:
                                        dev->enable_irq = val;
                                        mitsumi_cdrom_log("Mitsumi: IRQ mask=%02x, line=%d\n",
                                                          dev->enable_irq, dev->irq);
                                        break;
                                    default:
                                        break;
                                }
                                dev->cmdbuf[1]    = 0;
                                dev->cmdbuf_count = 2;
                                dev->conf         = 0;
                                break;
                            case 1:
                                if (dev->conf == 1) {
                                    dev->dmalen = val << 8;
                                    break;
                                }
                                dev->conf = val;
                                if (dev->conf == 1)
                                    dev->cmdrd_count++;
                                break;
                            default:
                                break;
                        }
                        break;
                    case CMD_READ1X:
                    case CMD_READ2X:
                        switch (dev->cmdrd_count) {
                            case 0: {
                                dev->readcount |= val;
                                dev->audio_end_msf |= val;
                                dev->cmdbuf_count = 0;
                                dev->first = 1;
                                dev->cdrom_dev->cur_speed = (dev->cmd == CMD_READ2X ? 2 : 1);
                                mitsumi_start_seek_phase(dev, 0);
                                break;
                            } case 1:
                                dev->readcount |= (val << 8);
                                dev->audio_end_msf |= val << 8;
                                break;
                            case 2:
                                dev->readcount    = ((val & 0x0f) << 16);
                                dev->audio_end_msf = val << 16;
                                dev->early_status = ((val & 0xf0) == 0xf0);
                                if (dev->early_status)
                                    mitsumi_cdrom_log("Mitsumi early-status read\n");
                                break;
                            case 5:
                                dev->readmsf = 0;
                                fallthrough;
                            case 4:
                            case 3:
                                /* Keep the command address in its native BCD form.
                                   mitsumi_msf_to_lba() validates and converts it
                                   when the transfer starts. */
                                dev->readmsf |= val << ((dev->cmdrd_count - 3) << 3);
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;
                }
                if (!dev->cmdrd_count)
                    dev->stat = mitsumi_status(dev);
                return;
            }
            dev->cmd          = val;
            dev->cmdbuf_idx   = 0;
            dev->cmdrd_count  = 0;
            dev->cmdbuf_count = 1;
            dev->stat         = mitsumi_status(dev);
            dev->cmdbuf[0]    = dev->stat;
            dev->data         = 0;
            switch (val) {
                case CMD_REQ_SENSE:
                    dev->cmdbuf[1]    = dev->cur_sense;
                    dev->cmdbuf_count = 2;
                    dev->cur_sense    = 0;
                    break;
                case CMD_SET_VOL:
                    dev->cmdrd_count = 4;
                    break;
                case CMD_DISC_INFO:
                    if (mitsumi_cdrom_is_ready(dev)) {
                        mitsumi_read_multisess(dev, &dev->cmdbuf[1]);
                        dev->cmdbuf_count = 5;
                        dev->readcount    = 0;
                    } else {
                        dev->cmdbuf_count = 1;
                        dev->cmdbuf[0]    = STAT_CMD_CHECK | dev->stat;
                    }
                    break;
                case CMD_GET_INFO:
                    if (mitsumi_cdrom_is_ready(dev)) {
                        dev->cmdbuf_count = 9;
                        dev->cmdbuf[0] = dev->stat;
                        mitsumi_disc_info(dev, &dev->cmdbuf[1]);
                        dev->readcount = 0;
                    } else {
                        dev->cmdbuf_count = 1;
                        dev->cmdbuf[0]    = STAT_CMD_CHECK | dev->stat;
                    }
                    break;
                case CMD_GET_VOL:
                    dev->cmdbuf_count = 5;
                    dev->cmdbuf[1]    = dev->cdrom_vols.att0;
                    dev->cmdbuf[2]    = dev->cdrom_vols.att1;
                    dev->cmdbuf[3]    = dev->cdrom_vols.att2;
                    dev->cmdbuf[4]    = dev->cdrom_vols.att3;
                    break;
                case CMD_GET_Q:
                    if (mitsumi_cdrom_is_ready(dev)) {
                        dev->cur_toc_track = cdrom_get_q(dev->cdrom_dev, &dev->cmdbuf[1], dev->cur_toc_track, dev->mode & MODE_GET_TOC);
                        dev->cmdbuf_count  = 11;
                        dev->readcount     = 0;
                        dev->cmdbuf[0]     = dev->stat;
                    } else {
                        dev->cmdbuf_count  = 1;
                        dev->cmdbuf[0]     = STAT_CMD_CHECK | dev->stat;
                    }
                    break;
                case CMD_GET_STAT:
                    /* The command prelude already captured and consumed status. */
                    break;
                case CMD_SET_MODE:
                    dev->cmdrd_count = 1;
                    break;
                case CMD_STOPCDDA:
                case CMD_STOP:
                    mitsumi_abort_read(dev);
                    cdrom_stop(dev->cdrom_dev);
                    dev->cur_toc_track = 0;
                    break;
                case CMD_CONFIG:
                    dev->cmdrd_count = 2;
                    break;
                case CMD_READ1X:
                case CMD_READ2X:
                    if (mitsumi_cdrom_is_ready(dev)) {
                        mitsumi_abort_read(dev);
                        dev->readcount     = 0;
                        dev->audio_end_msf = 0;
                        dev->drvmode       = DRV_MODE_CDDA;
                        dev->cmdrd_count   = 6;
                    } else {
                        dev->cmdbuf_count = 1;
                        dev->cmdbuf[0]    = STAT_CMD_CHECK;
                    }
                    break;
                case CMD_GET_VER:
                    dev->cmdbuf[0]    = dev->stat;
                    dev->cmdbuf[1]    = 'D';
                    dev->cmdbuf[2]    = 0x10;
                    dev->cmdbuf_count = 3;
                    break;
                case CMD_CLOSE:
                    if (dev->tray_open) {
                        dev->tray_open = 0;
                        cdrom_reload(dev->cdrom_dev->id);
                        dev->change = (mitsumi_cdrom_is_ready(dev)) ? 2 : 1;
                    }
                    dev->stat = mitsumi_status(dev);
                    dev->cmdbuf[0] = dev->stat;
                    break;
                case CMD_EJECT:
                    if (dev->locked) {
                        dev->cur_sense = 4;
                        dev->cmdbuf[0] = dev->stat | STAT_ERROR | STAT_CMD_CHECK;
                        mitsumi_set_irq(dev, IRQ_ERROR);
                    } else {
                        mitsumi_abort_read(dev);
                        cdrom_stop(dev->cdrom_dev);
                        cdrom_eject(dev->cdrom_dev->id);
                        dev->tray_open = 1;
                        dev->change = 1;
                        dev->stat = mitsumi_status(dev);
                        dev->cmdbuf[0] = dev->stat;
                    }
                    break;
                case CMD_LOCK:
                case CMD_SET_SMODE:
                    dev->cmdrd_count = 1;
                    break;
                case CMD_SOFT_RESET:
                    mitsumi_cdrom_log("Mitsumi soft reset\n");
                    mitsumi_cdrom_reset(dev);
                    dev->cmdbuf_count = 1;
                    dev->cmdbuf[0]    = dev->stat;
                    break;
                default:
                    dev->cmdbuf[0] = dev->stat | STAT_CMD_CHECK;
                    mitsumi_cdrom_log("Mitsumi: unhandled command %02X\n", val);
                    break;
            }
            mitsumi_print_cmd(dev, val);
            break;
        case 1:
            dev->cmdbuf_count = 1;
            dev->cmdbuf[0]    = dev->stat;
            break;
        case 2:
            dev->cur_control  = val;
            break;
        case 3:
            /* MTMCDAE uses this register to select the DMA transfer mode
               (40h followed by the channel selector, e.g. 45h for DMA 5).
               Only a zero write is a hardware reset request. */
            if (!val)
                mitsumi_cdrom_reset(dev);
            break;
        default:
            break;
    }
}

uint32_t
mitsumi_get_volume(void *priv, int channel)
{
    mcd_t   *dev      = (mcd_t *) priv;

    switch (channel & 3) {
        default:
            break;
        case 0:
            return dev->cdrom_vols.att0;
        case 1:
            return dev->cdrom_vols.att2;
        case 2:
            return dev->cdrom_vols.att1;
        case 3:
            return dev->cdrom_vols.att3;
    }
    return dev->cdrom_vols.att0;
}

uint32_t
mitsumi_get_channel(void *priv, int channel)
{
    mcd_t   *dev      = (mcd_t *) priv;

    /* att0/att1 are the left output's left/right gains.  att3/att2
       are the corresponding gains for the right output. */
    return (channel == 0) ? ((!!(dev->cdrom_vols.att0)) | ((!!(dev->cdrom_vols.att1)) << 1)) :
                            ((!!(dev->cdrom_vols.att3)) | ((!!(dev->cdrom_vols.att2)) << 1));
}

static void *
mitsumi_cdrom_init(UNUSED(const device_t *info))
{
    mcd_t *dev = calloc(1, sizeof(mcd_t));

    for (uint8_t i = 0; i < CDROM_NUM; i++) {
        if (cdrom[i].bus_type == CDROM_BUS_MITSUMI) {
            dev->cdrom_dev = &cdrom[i];
            break;
        }
    }

    if (!dev->cdrom_dev) {
        free(dev);
        return NULL;
    }

    dev->cdrom_dev->priv        = dev;
    dev->cdrom_dev->insert      = mitsumi_cdrom_insert;
    dev->cdrom_dev->get_volume  = mitsumi_get_volume;
    dev->cdrom_dev->get_channel = mitsumi_get_channel;
    dev->cdrom_dev->cached_sector = -1;
    dev->cdrom_dev->subc_sector = -1;

    dev->base = device_get_config_hex16("base");
    dev->irq  = device_get_config_int("irq");
    dev->dma  = device_get_config_int("dma");

    io_sethandler(dev->base, 4,
                  mitsumi_cdrom_in, NULL, NULL, mitsumi_cdrom_out, NULL, NULL, dev);

    timer_add(&dev->dma_timeout_timer, mitsumi_dma_timeout_callback, dev, 0);
    timer_add(&dev->read_timer, mitsumi_read_callback, dev, 0);

    mitsumi_cdrom_reset(dev);

    return dev;
}

static void
mitsumi_cdrom_close(void *priv)
{
    mcd_t *dev = (mcd_t *) priv;

    if (dev) {
        dma_set_service_handler(dev->dma, NULL, NULL);
        mitsumi_abort_read(dev);
        io_removehandler(dev->base, 4,
                         mitsumi_cdrom_in, NULL, NULL, mitsumi_cdrom_out, NULL, NULL, dev);
        picintc(1 << dev->irq);
        if (dev->cdrom_dev && (dev->cdrom_dev->priv == dev)) {
            dev->cdrom_dev->priv        = NULL;
            dev->cdrom_dev->insert      = NULL;
            dev->cdrom_dev->get_volume  = NULL;
            dev->cdrom_dev->get_channel = NULL;
        }
        free(dev);
    }
}

static void
mitsumi_cdrom_device_reset(void *priv)
{
    mcd_t *dev = (mcd_t *) priv;

    if (dev)
        mitsumi_cdrom_reset(dev);
}

static const device_config_t mitsumi_config[] = {
    // clang-format off
    {
        .name           = "base",
        .description    = "Address",
        .type           = CONFIG_HEX16,
        .default_string = NULL,
        .default_int    = 0x310,
        .file_filter    = NULL,
        .spinner        = { 0 },
        .selection      = {
            { .description = "300H", .value = 0x300 },
            { .description = "310H", .value = 0x310 },
            { .description = "320H", .value = 0x320 },
            { .description = "340H", .value = 0x340 },
            { .description = "350H", .value = 0x350 },
            { NULL                                  }
        },
        .bios           = { { 0 } }
    },
    {
        .name           = "irq",
        .description    = "IRQ",
        .type           = CONFIG_SELECTION,
        .default_string = NULL,
        .default_int    = 10,
        .file_filter    = NULL,
        .spinner        = { 0 },
        .selection      = {
            { .description = "IRQ 3",  .value =  3 },
            { .description = "IRQ 5",  .value =  5 },
            { .description = "IRQ 9",  .value =  9 },
            { .description = "IRQ 10", .value = 10 },
            { .description = "IRQ 11", .value = 11 },
            { .description = ""                    }
        },
        .bios           = { { 0 } }
    },
    {
        .name           = "dma",
        .description    = "DMA",
        .type           = CONFIG_SELECTION,
        .default_string = NULL,
        .default_int    = 5,
        .file_filter    = NULL,
        .spinner        = { 0 },
        .selection      = {
            { .description = "DMA 5", .value = 5 },
            { .description = "DMA 6", .value = 6 },
            { .description = "DMA 7", .value = 7 },
            { .description = ""                  }
        },
        .bios           = { { 0 } }
    },
    { .name = "", .description = "", .type = CONFIG_END }
// clang-format off
};

const device_t mitsumi_cdrom_device = {
    .name          = "Mitsumi interface",
    .internal_name = "mcd",
    .flags         = DEVICE_ISA16,
    .local         = 0,
    .init          = mitsumi_cdrom_init,
    .close         = mitsumi_cdrom_close,
    .reset         = mitsumi_cdrom_device_reset,
    .available     = NULL,
    .speed_changed = NULL,
    .force_redraw  = NULL,
    .config        = mitsumi_config
};

/*============================================================================

This C source file is part of the SoftFloat IEEE Floating-Point Arithmetic
Package, Release 3e, by John R. Hauser.

Copyright 2011, 2012, 2013, 2014, 2015, 2016 The Regents of the University of
California.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

 1. Redistributions of source code must retain the above copyright notice,
    this list of conditions, and the following disclaimer.

 2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions, and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

 3. Neither the name of the University nor the names of its contributors may
    be used to endorse or promote products derived from this software without
    specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS "AS IS", AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ARE
DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

=============================================================================*/

#include <stdbool.h>
#include <stdint.h>
#include "internals.h"
#include "specialize.h"
#include "softfloat.h"

uint64_t f128_to_ui64_r_minMag(float128_t a, bool exact, struct softfloat_status_t *status)
{
    uint64_t uiA64, uiA0;
    bool sign;
    int32_t exp;
    uint64_t sig64, sig0;
    int32_t shiftDist;
    int8_t negShiftDist;
    uint64_t z;

    /*------------------------------------------------------------------------
    *------------------------------------------------------------------------*/
    uiA64 = a.v64;
    uiA0  = a.v0;
    sign  = signF128UI64(uiA64);
    exp   = expF128UI64(uiA64);
    sig64 = fracF128UI64(uiA64);
    sig0  = uiA0;
    /*------------------------------------------------------------------------
    *------------------------------------------------------------------------*/
    shiftDist = 0x402F - exp;
    if (shiftDist < 0) {
        /*--------------------------------------------------------------------
        *--------------------------------------------------------------------*/
        if (sign || (shiftDist < -15)) goto invalid;
        sig64 |= UINT64_C(0x0001000000000000);
        negShiftDist = -shiftDist;
        z = sig64<<negShiftDist | sig0>>(shiftDist & 63);
        if (exact && (uint64_t) (sig0<<negShiftDist)) {
            softfloat_raiseFlags(status, softfloat_flag_inexact);
        }
    } else {
        /*--------------------------------------------------------------------
        *--------------------------------------------------------------------*/
        if (49 <= shiftDist) {
            if (exact && (exp | sig64 | sig0)) {
                softfloat_raiseFlags(status, softfloat_flag_inexact);
            }
            return 0;
        }
        /*--------------------------------------------------------------------
        *--------------------------------------------------------------------*/
        if (sign) goto invalid;
        sig64 |= UINT64_C(0x0001000000000000);
        z = sig64>>shiftDist;
        if (exact && (sig0 || (z<<shiftDist != sig64))) {
            softfloat_raiseFlags(status, softfloat_flag_inexact);
        }
    }
    return z;
    /*------------------------------------------------------------------------
    *------------------------------------------------------------------------*/
 invalid:
    softfloat_raiseFlags(status, softfloat_flag_invalid);
    return
        (exp == 0x7FFF) && (sig64 | sig0) ? ui64_fromNaN
            : sign ? ui64_fromNegOverflow : ui64_fromPosOverflow;
}
